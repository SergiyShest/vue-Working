import { Selector } from 'testcafe';

fixture `New Fixture`
    .page `sql.ru`;

test('New Test', async t => {
    await t
        .typeText(Selector('#search-query'), 'testCafe')
        .click(Selector('#top-search').find('div').find('input').nth(1));
});